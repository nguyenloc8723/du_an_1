<?php
// thông tin kết nối của cơ sở dữ liệu
define("DB_HOST","localhost");
define("DB_NAME","ldshop");
define("DB_USER","root");
define("DB_PWD","");
?>