<?php
//chứa nội dung
//view của tôi ở đâu ?  
if(isset($view)) {
    include ($view);
}
?>