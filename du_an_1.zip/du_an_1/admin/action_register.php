<?php
include("controllers/c_user.php");
$c_user = new c_user();
$c_user->checkRegister();
?>