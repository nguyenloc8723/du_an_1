<?php
session_start();
class c_contact {
  public function index(){


    $view = "views/v_lien_he/v_lien_he.php";
    include("templates/layout.php");

  }
}